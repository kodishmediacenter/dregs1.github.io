# -*- coding: utf-8 -*-
import six
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
try:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
try:
    from urllib.request import Request, urlopen, URLError, HTTPError  # Python 3
except ImportError:
    from urllib2 import Request, urlopen, URLError, HTTPError # Python 2    
import sys
import os
import re
try:
    import json
except:
    import simplejson as json
import time
import base64


plugin = sys.argv[0]
handle = int(sys.argv[1])

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addonid = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
dialog = xbmcgui.Dialog()

URL_BASE = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x61\x77\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x61\x72\x72\x6f\x77\x6e\x65\x67\x72\x61\x2f\x61\x64\x64\x6f\x6e\x2f\x6d\x61\x69\x6e\x2f\x61\x64\x64\x6f\x6e\x6b\x2d\x70\x74\x2f\x66\x6c\x65\x74\x6f\x70\x2e\x78\x6d\x6c'

class XstreamPlayer(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self, *args, **kwargs)
        self.streamFinished = False
        self.streamSuccess = True
        self.playedTime = 0
        self.totalTime = 999999
        #log(LOGMESSAGE + ' -> [player]: player instance created', LOGNOTICE)

    def play(self, url, listitem):
        #print 'Now im playing... %s' % url
        xbmc.Player().play(url, listitem)        

    def onPlayBackStarted(self):
        #log(LOGMESSAGE + ' -> [player]: starting Playback', LOGNOTICE)
        self.totalTime = self.getTotalTime()

    def onPlayBackStopped(self): #Will be called when user stops xbmc playing a file
        #log(LOGMESSAGE + ' -> [player]: Playback stopped', LOGNOTICE)
        if self.playedTime == 0 and self.totalTime == 999999:
            self.streamSuccess = False
            #log(LOGMESSAGE + ' -> [player]: Kodi failed to open stream', LOGERROR)
        self.streamFinished = True

    def onPlayBackEnded(self): ## Will be called when xbmc stops playing a file
        #log(LOGMESSAGE + ' -> [player]: Playback completed', LOGNOTICE)
        self.onPlayBackStopped()

def select_op(name,items):
    op = dialog.select(name, items)
    return op

def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, iconimage, time, sound=sound)

def get_url(params):
    if params:
        url = '%s?%s'%(plugin, urlencode(params))
    else:
        url = ''
    return url

def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string

def search():
    vq = get_search_string(heading='Digite a pesquisa', message="")        
    if ( not vq ): return False
    title = vq
    return title

def item(params,folder=True):
    u = get_url(params)
    if not u:
        u = ''
    name = params.get("name")
    if name:
        name = name
    else:
        name = 'Unknow'
    iconimage = params.get("iconimage")
    fanart = params.get("fanart")
    description = params.get("description")
    if not description:
        description = ''
    playable = params.get("playable")
    liz = xbmcgui.ListItem(name)
    liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
    if playable:
        if playable == 'true':
            liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
    return ok



def get_src(url,headers=False):
    try:
        req = Request(url)
        if headers:
            for key, value in headers.items():
                req.add_header(key, value)
        else:
            req.add_header('User-Agent', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36')
            response = urlopen(req,timeout=20)
            data = response.read()
        try:
            data = data.decode('utf-8')
        except:
            pass
    except:
        data = ''
    if data:
        import gzip, binascii
        k = base64.b32decode('\x47\x46\x54\x44\x51\x59\x52\x51\x48\x41\x59\x44\x51\x5a\x42\x54\x47\x51\x32\x44\x49\x4e\x49\x3d').decode('utf-8')
        try:
            from StringIO import StringIO as BytesIO ## for Python 2
        except ImportError:            
            from io import BytesIO ## for Python 3
        if k in data:
            data = data.split(k)
            buf = BytesIO(binascii.unhexlify(data[0]))
            f = gzip.GzipFile(fileobj=buf)
            data = f.read()
            try:
                data = data.decode('utf-8') if six.PY3 else data
            except:
                pass
    return data



def getData(url):
    data = get_src(url)
    get_m3u8(url,data)



def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match


def detect_f4mtester():
    folder = 'special://home/addons/plugin.video.f4mTester'
    if os.path.exists(translate(folder)):
        f4m = True
    else:
        f4m = False
    return f4m

def checkf4mtester():
    if not detect_f4mtester():
        try:
            xbmc.executebuiltin('InstallAddon(plugin.video.f4mTester)', wait=True)
            time.sleep(10)
        except:
            pass

def get_m3u8(url,data):
    #checkf4mtester()
    #f4mtester = True
    content = data.rstrip()
    match1 = re.findall(r'#EXTINF:.+?tvg-logo="(.*?)".+?group-title="(.*?)",(.*?)[\n\r]+([^\r\n]+)', content)
    if match1:
        group_list = []
        for thumbnail,cat,channel_name,stream_url in match1:
            if not cat in group_list:
                group_list.append(cat)
                if cat == '':
                    cat = 'Desconhecido'
                try:
                    cat = cat.encode('utf-8', 'ignore')
                except:
                    pass
                try:
                    url = url.encode('utf-8', 'ignore')
                except:
                    pass
                item({'name': cat, 'action': 'openm3u', 'url': url},folder=True)
    else:
        match2 = re.findall(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)', content)
        group_list = []
        for other,channel_name,stream_url in match2:
            if 'tvg-logo' in other:
                thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
                if thumbnail:
                    if thumbnail.startswith('http'):
                        thumbnail = thumbnail
                    else:
                        thumbnail = ''
                else:
                    thumbnail = ''
            else:
                thumbnail = ''

            if 'group-title' in other:
                cat = re_me(other,'group-title=[\'"](.*?)[\'"]')
            else:
                cat = ''
            if six.PY2:
                if cat:
                    try:
                        cat = cat.encode('utf-8', 'ignore')
                    except:
                        pass
            if cat:
                if not cat in group_list:
                    group_list.append(cat)
                    item({'name': cat, 'action': 'openm3u', 'url': url},folder=True)
            else:
                if six.PY2:
                    try:
                        channel_name = channel_name.encode('utf-8', 'ignore')
                    except:
                        pass                        
                # if not 'plugin' in stream_url and not 'User-Agent' in stream_url and not 'Referer' in stream_url and not 'Origin' in stream_url and not 'Cookie' in stream_url:
                #     stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36'
                # if '.m3u8' in stream_url and f4mtester and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
                #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
                # elif f4mtester and not '.mp4' in stream_url and not '.mkv' in stream_url and not '.avi' in stream_url and not '.rmvb' in stream_url and not '.mp3' in stream_url and not '.wmv' in stream_url and not '.wma' in stream_url and not '.ac3' in stream_url and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
                #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
                # if 'f4mTester' in stream_url:
                #     stream_url = stream_url.replace('&amp;streamtype=', '&streamtype=').replace('&amp;name=', '&name=').replace('&amp;iconImage=', '&iconImage=').replace('&amp;thumbnailImage=', '&thumbnailImage=').replace('&amp;url=', '&url=')
                else:
                    try:
                        stream_url = stream_url.encode('utf-8', 'ignore')
                    except:
                        pass
                    item({'name': channel_name, 'action': 'playitem', 'url': stream_url, 'iconimage': thumbnail},folder=False)
        if not match2:
            infoDialog('Nenhuma lista m3u', iconimage='INFO', time=30)
    xbmcplugin.endOfDirectory(handle)

def get_search(url,search):
    #f4mtester = True
    data = get_src(url)
    content = data.rstrip()
    match2 = re.findall(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)', content)
    for other,channel_name,stream_url in match2:
        if 'tvg-logo' in other:
            thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
            if thumbnail:
                if thumbnail.startswith('http'):
                    thumbnail = thumbnail
                else:
                    thumbnail = ''
            else:
                thumbnail = ''
        else:
            thumbnail = ''

        if 'group-title' in other:
            cat = re_me(other,'group-title=[\'"](.*?)[\'"]')
        else:
            cat = ''
        if six.PY2:
            try:
                channel_name = channel_name.encode('utf-8', 'ignore')
            except:
                pass                        
        # if not 'plugin' in stream_url and not 'User-Agent' in stream_url and not 'Referer' in stream_url and not 'Origin' in stream_url and not 'Cookie' in stream_url:
        #     stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36'
        # if '.m3u8' in stream_url and f4mtester and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
        #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
        # elif f4mtester and not '.mp4' in stream_url and not '.mkv' in stream_url and not '.avi' in stream_url and not '.rmvb' in stream_url and not '.mp3' in stream_url and not '.wmv' in stream_url and not '.wma' in stream_url and not '.ac3' in stream_url and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
        #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
        # if 'f4mTester' in stream_url:
        #     stream_url = stream_url.replace('&amp;streamtype=', '&streamtype=').replace('&amp;name=', '&name=').replace('&amp;iconImage=', '&iconImage=').replace('&amp;thumbnailImage=', '&thumbnailImage=').replace('&amp;url=', '&url=')
        else:
            try:
                stream_url = stream_url.encode('utf-8', 'ignore')
            except:
                pass
        if re.search(search,channel_name,re.IGNORECASE):
            item({'name': channel_name, 'action': 'playitem', 'url': stream_url, 'iconimage': thumbnail},folder=False)
    if not match2:
        infoDialog('Nenhuma lista m3u', iconimage='INFO', time=30)
    xbmcplugin.endOfDirectory(handle)    



def get_m3u8_2(name,url):
    #checkf4mtester()
    f4mtester = True
    try:
        name = name.decode('utf-8')
    except:
        pass        
    if name == 'Desconhecido':
        name = ''
    data = get_src(url)
    if re.search("#EXTM3U",data) or re.search("#EXTINF",data):
        xbmcplugin.setContent(handle, 'videos')
        content = data.rstrip()
        match1 = re.findall(r'#EXTINF:.+?tvg-logo="(.*?)".+?group-title="(.*?)",(.*?)[\n\r]+([^\r\n]+)', content)
        if match1:
            for thumbnail,cat,channel_name,stream_url in match1:
                if cat == name:
                    if six.PY2:
                        try:
                            channel_name = channel_name.encode('utf-8', 'ignore')
                        except:
                            pass                        
                    # if not 'plugin' in stream_url and not 'User-Agent' in stream_url and not 'Referer' in stream_url and not 'Origin' in stream_url and not 'Cookie' in stream_url:
                    #     stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36'
                    # if '.m3u8' in stream_url and f4mtester and not 'pluto.tv' in stream_url and not 'plugin' in stream_url and not stream_url.startswith(sv_vip):
                    #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
                    # elif f4mtester and not '.mp4' in stream_url and not '.mkv' in stream_url and not '.avi' in stream_url and not '.rmvb' in stream_url and not '.mp3' in stream_url and not '.wmv' in stream_url and not '.wma' in stream_url and not '.ac3' in stream_url and not 'pluto.tv' in stream_url and not 'plugin' in stream_url and not stream_url.startswith(sv_vip):
                    #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
                    # if 'f4mTester' in stream_url:
                    #     stream_url = stream_url.replace('&amp;streamtype=', '&streamtype=').replace('&amp;name=', '&name=').replace('&amp;iconImage=', '&iconImage=').replace('&amp;thumbnailImage=', '&thumbnailImage=').replace('&amp;url=', '&url=')
                    try:
                        stream_url = stream_url.encode('utf-8', 'ignore')
                    except:
                        pass                       
                    item({'name': channel_name, 'action': 'playitem', 'url': stream_url, 'iconimage': thumbnail},folder=False)
        elif not match1:
            match2 = re.findall(r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)', content)
            group_list = []
            for other,channel_name,stream_url in match2:
                if 'tvg-logo' in other:
                    thumbnail = re_me(other,'tvg-logo=[\'"](.*?)[\'"]')
                    if thumbnail:
                        if thumbnail.startswith('http'):
                            thumbnail = thumbnail
                        else:
                            thumbnail = ''
                    else:
                        thumbnail = ''
                else:
                    thumbnail = ''

                if 'group-title' in other:
                    cat = re_me(other,'group-title=[\'"](.*?)[\'"]')
                else:
                    cat = ''
                if cat:
                    if cat == name:
                        try:
                            channel_name = channel_name.encode('utf-8', 'ignore')
                        except:
                            pass                            
                        # if not 'plugin' in stream_url and not 'User-Agent' in stream_url and not 'Referer' in stream_url and not 'Origin' in stream_url and not 'Cookie' in stream_url:
                        #     stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36'
                        # if '.m3u8' in stream_url and f4mtester and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
                        #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
                        # elif f4mtester and not '.mp4' in stream_url and not '.mkv' in stream_url and not '.avi' in stream_url and not '.rmvb' in stream_url and not '.mp3' in stream_url and not '.wmv' in stream_url and not '.wma' in stream_url and not '.ac3' in stream_url and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
                        #     stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
                        # if 'f4mTester' in stream_url:
                        #     stream_url = stream_url.replace('&amp;streamtype=', '&streamtype=').replace('&amp;name=', '&name=').replace('&amp;iconImage=', '&iconImage=').replace('&amp;thumbnailImage=', '&thumbnailImage=').replace('&amp;url=', '&url=')
                        try:
                            stream_url = stream_url.encode('utf-8', 'ignore')
                        except:
                            pass                            
                        item({'name': channel_name, 'action': 'playitem', 'url': stream_url, 'iconimage': thumbnail},folder=False)
            if not match2:
                infoDialog('[COLOR red]Nenhum dado encontrado![/COLOR]', iconimage='ERROR', time=30)
        xbmcplugin.endOfDirectory(handle)                                                                          





def playvideo(channel_name,stream_url,thumbnail,fanart,description,sub,playable=False):
    # if url.startswith('plugin://') and not 'youtube' in url and not 'tubemusic' in url:
    #     xbmc.executebuiltin('RunPlugin(%s)'%url)
    # else:
    #     liz = xbmcgui.ListItem(name)
    #     liz.setPath(url)      
    #     liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage})
    #     if not description:
    #         description = ''
    #     liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
    #     if sub:
    #         liz.setSubtitles([sub])
    #     if playable:
    #         xbmc.Player().play(item=url, listitem=liz)
    #     else:
    #         xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    itens = ['F4MTESTER', 'PADRÃO']
    op = select_op('SELECIONE UMA OPÇÃO:', itens)
    if op >= 0:
        if op == 0:
            if not 'plugin' in stream_url and not 'User-Agent' in stream_url and not 'Referer' in stream_url and not 'Origin' in stream_url and not 'Cookie' in stream_url:
                stream_url = stream_url + '|User-Agent=Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36'
            if '.m3u8' in stream_url and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
                stream_url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
            elif not '.mp4' in stream_url and not '.mkv' in stream_url and not '.avi' in stream_url and not '.rmvb' in stream_url and not '.mp3' in stream_url and not '.wmv' in stream_url and not '.wma' in stream_url and not '.ac3' in stream_url and not 'pluto.tv' in stream_url and not 'plugin' in stream_url:
                stream_url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&name=[COLOR cyan]@by_flecha_negra[/COLOR]'+quote_plus(str(channel_name))+'&iconImage='+quote_plus(thumbnail)+'&thumbnailImage='+quote_plus(thumbnail)+'&url='+quote_plus(stream_url)
            xbmc.executebuiltin('RunPlugin(%s)'%stream_url)
        elif op == 1:
            liz = xbmcgui.ListItem(channel_name)
            liz.setPath(stream_url)
            liz.setArt({"fanart": fanart, "icon": thumbnail, "thumb": thumbnail})
            if not description:
                description = ''
            liz.setInfo(type='video', infoLabels={'Title': channel_name, 'plot': description })
            xbmcPlayer = XstreamPlayer()
            monitor = xbmc.Monitor()
            xbmcPlayer.play(stream_url,liz)
            while (not monitor.abortRequested()) & (not xbmcPlayer.streamFinished):
                if xbmcPlayer.isPlayingVideo():
                    xbmcPlayer.playedTime = xbmcPlayer.getTime()
                monitor.waitForAbort(10)            




def menu():
    item({'name': '[B]CANAIS[/B]', 'action': 'open', 'iconimage': icon},folder=True)
    #item({'name': '[B]PESQUISAR[/B]', 'action': 'pesquisar', 'iconimage': icon},folder=True)
    xbmcplugin.endOfDirectory(handle)


def run():
    args = parse_qs(sys.argv[2][1:])
    action = args.get("action")
    name = args.get("name")
    url = args.get("url")
    iconimage = args.get("iconimage")
    fanart = args.get("fanart")
    description = args.get("description")
    playable = args.get("playable")
    if name:
        name = name[0]
    else:
        name = 'Unknow'
    if url:
        url = url[0]
    else:
        url = URL_BASE
    if iconimage:
        iconimage = iconimage[0]
    else:
        iconimage = ''
    if fanart:
        fanart = fanart[0]
    else:
        fanart = ''
    if description:
        description = description[0]
    else:
        description = ''
    if playable:
        playable = playable[0]
        if playable == 'true':
            playable = False
        else:
            playable = True
    else:
        playable = True
    if action == None:
        menu()
    elif 'open' in action:
        getData(url)
    elif 'pesquisar' in action:
        pesquisa = search()
        if pesquisa:
            get_search(url,pesquisa)
    elif 'playitem' in action:
        playvideo(name,url,iconimage,fanart,description,'',playable=playable)
    elif 'openm3u' in action:      
        get_m3u8_2(name,url)